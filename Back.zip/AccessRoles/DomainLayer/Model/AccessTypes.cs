﻿using System.ComponentModel.DataAnnotations;

namespace DomainLayer.Model
{
    public class AccessTypes
    {
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string AccessLevel { get; set; }
    }
}
