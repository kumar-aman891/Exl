import { LogLevel } from "@azure/msal-browser";

export const msalConfig = {
    auth:{
        clientId:"d7aee664-b80f-4170-b4b9-bfa97f5bbf91",
        authority:"https://login.microsoftonline.com/931eec82-88ee-4cb9-9b24-0c13e2d66aab",
        redirectUri:"/",
        postLogoutRedirectUri:"/",
        navigateToLoginRequestUrl: false,
    },
    cache: {
        cacheLocation: 'sessionStorage',
        storeAuthStateInCookie: false,
    },
    system: {
        loggerOptions:{
            loggerCallback: (level: any, message: any, containsPii: any) => {
                if(containsPii){
                    return;
                }
                switch(level){
                    case LogLevel.Error:
                        console.error(message);
                        return;
                    case LogLevel.Info:
                        console.info(message);
                        return;
                    case LogLevel.Verbose:
                        console.debug(message);
                        return;
                    case LogLevel.Warning:
                        console.error(message);
                        return;
                    default:
                        return;
                }
            },
        },
    },

};

export const loginRequest = {
    scopes: ['user.read'],
};