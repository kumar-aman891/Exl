import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import './DropDown.scss'; // Import the SCSS file
import { IoIosArrowDown } from "react-icons/io";

const DropDown: React.FC = () => {
    return(
        
        <div className="wrapper">
        <div className='PleaseSelect'>Please Select</div>
        <div className="row">
            <div className="col">
                <div className='col-content'>
                <select className="form-control"  name="month" id="month">
                <option value="" disabled selected>Month</option> {/* Placeholder option */}
                    <option value="01">January</option>
                    <option value="02">February</option>
                    <option value="03">March</option>
                    <option value="04">April</option>
                    <option value="05">May</option>
                    <option value="06">June</option>
                    <option value="07">July</option>
                    <option value="08">August</option>
                    <option value="09">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>
                </select>
                <div className="arrow-icon"> {/* Wrapper div for arrow icon */}
                        <IoIosArrowDown />
                    </div>
                </div>
            </div>
            <div className="col">
                <div className="col-content">
                <select className="form-control"  name="year" id="year">
                <option value="" disabled selected>Year</option> {/* Placeholder option */}
                <option value="2022">2022</option>
                <option value="2023">2023</option>
                <option value="2024">2024</option>
                </select>
                <div className="arrow-icon"> {/* Wrapper div for arrow icon */}
                        <IoIosArrowDown />
                    </div>
            </div>
            </div>
        </div>
    </div>  
    )

}

export default DropDown;

