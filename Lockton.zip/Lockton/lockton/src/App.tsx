import React from "react";
import Login from "./components/Login/Login";
import LoginCreds from "./components/Login/LoginCreds";
import styles from './App.module.css';
import LoginBackgroundImg from "./components/Login/LoginBackgroundImg";
import UploadEmpMemCount from "./components/Upload/UploadEmpMemCount";
import Upload from "./components/Upload/Upload";
import DropDown from "./components/Upload/DropDown";
const handleOnClick = () => {
  // Hardcoded email and password
  //const email = "example@example.com";
  //const password = "password123";

  // API call to authenticate user and get token

  const token = "your_token_here";

  // Save the token in sessionStorage
  sessionStorage.setItem("auth-token", token);

  //console.log("Login Clicked. Token saved in sessionStorage:", token);

  // Check if a token exists in sessionStorage
const token_available = sessionStorage.getItem("auth-token");

if (token_available) {
  console.log("Token exists in sessionStorage:", token_available);
} else {
  console.log("Token does not exist in sessionStorage.");
}

}


const App: React.FC = () =>  {
  return (
    <div className="App">
      {/* <LoginBackgroundImg/> */}
      {/* <Login handleOnClick={handleOnClick}/> */}
      {/* <LoginCreds/> */}
    {/* <Upload/> */}
    <UploadEmpMemCount/>
    {/* <DropDown/> */}
    </div>
  );
}

export default App;
