﻿using Final_Year_Project.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Final_Year_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly DAL _dal;

        public UsersController(DAL dal)
        {
            _dal = dal;
        }

        [HttpGet("AccessDetails")]
        public async Task<IActionResult> AccessDetails(int groupId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _dal.AccessDetails(groupId);
            if (user == null)
            {
                return Unauthorized("Invalid group id.");
            }

            return Ok(user);
        }
    }
}
