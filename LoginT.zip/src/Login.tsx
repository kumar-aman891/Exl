import React, { useState } from 'react';
import { AuthenticatedTemplate, useMsal, UnauthenticatedTemplate } from '@azure/msal-react';
import { loginRequest } from './auth-config';
import "bootstrap/dist/css/bootstrap.min.css";
import styles from "./Login.module.css";

const Login = () => {
  const { instance } = useMsal();
  const activeAccount = instance.getActiveAccount();
  console.log(activeAccount);
  
  const handleLogin = () => {
    instance
      .loginRedirect({
        ...loginRequest,
        prompt: 'create',
      })
      .catch((error) => console.log(error));
  };
  return (
    <div>
      <div className={`${styles.loginContainer}`}>
        {/* <img className={styles.locktonLogoImage} src={LocktonLogo} alt="LocktonLogo"/> */}
        <h2 className={styles.welcomeRxMartMessage}>Welcome to Rx Mart</h2> 
        <h5 className={styles.welcomeMessage}>Let's get Started!</h5>
        <AuthenticatedTemplate>
          {activeAccount ? (
            <p>Authenticated Successfully</p>
          ) : null}
        </AuthenticatedTemplate>
        <UnauthenticatedTemplate>
          <button type="button" className={`btn btn-primary ${styles.loginButton}`} onClick={handleLogin}>Login</button>
        </UnauthenticatedTemplate>
      </div>
    </div>
  );
};

export default Login;
