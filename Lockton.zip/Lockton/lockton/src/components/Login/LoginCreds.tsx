import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import styles from "./LoginCreds.module.css";

interface LoginCredsProps {
  value: any; // Adjust type as needed
}

const LoginCreds: React.FC = () => {
  return (
    <div className={styles.loginContainer}>
      <form className={styles.loginForm}>
        <div className="container">
          <ul className="nav nav-underline justify-content-center">
            <li className="nav-item">
              <a className="nav-link" href="#">
                Login
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Registration
              </a>
            </li>
          </ul>
        </div>
        <div className="mb-3">
          <label
            htmlFor="exampleInputEmail1"
            className={`form-label ${styles.formLabel}`}
          >
            Email address
          </label>
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
          />
        </div>
        <div className="mb-3">
          <label
            htmlFor="exampleInputPassword1"
            className={`form-label ${styles.formLabel}`}
          >
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
          />
        </div>
        <div className="d-flex justify-content-center flex-column">
          <button
            type="submit"
            className={`btn btn-primary ${styles.loginButton}`}
          >
            Login
          </button>
          <a
            href="#"
            style={{ color: "white", margin: "auto", textDecoration: "none" }}
          >
            Forgot Password?
          </a>
        </div>
      </form>
    </div>
  );
}

export default LoginCreds;