Create database FinalYearProject;
USE FinalYearProject;

CREATE TABLE Users(ID INT IDENTITY(1,1), Name VARCHAR(100));
CREATE TABLE AccessTypes(ID INT IDENTITY(1,1), AccessLevel VARCHAR(100));
CREATE TABLE Groups(ID INT IDENTITY(1,1), GroupName VARCHAR(100));
CREATE TABLE AccessMapping(ID INT IDENTITY(1,1), GroupID INT, UserID INT, AccessTypeID INT);

INSERT INTO Users VALUES('Mark'); INSERT INTO Users VALUES('David');
INSERT INTO AccessTypes VALUES('Read'); INSERT INTO AccessTypes VALUES('Write');  INSERT INTO AccessTypes VALUES('Read/Write');
INSERT INTO Groups VALUES('Group 1'); INSERT INTO Groups VALUES('Group 2'); 
INSERT INTO AccessMapping VALUES(1,1,1); INSERT INTO AccessMapping VALUES(1,1,2); INSERT INTO AccessMapping VALUES(1,1,3);
INSERT INTO AccessMapping VALUES(1,2,1); INSERT INTO AccessMapping VALUES(1,2,2); 

SELECT * FROM Users;
SELECT * FROM AccessTypes;
SELECT * FROM Groups;
SELECT * FROM AccessMapping;


CREATE PROCEDURE GetUserDetails 
    @groupId int  
AS  
BEGIN  
    SELECT UserID, Name, GroupName, AccessLevel
	FROM Groups G
	INNER JOIN AccessMapping AM ON AM.GroupID = G.ID
    INNER JOIN Users U ON AM.UserID = U.ID
	INNER JOIN AccessTypes AT ON AT.ID = AM.AccessTypeID
    WHERE G.ID = @groupId;
END