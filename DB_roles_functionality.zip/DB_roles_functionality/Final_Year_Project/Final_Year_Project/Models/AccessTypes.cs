﻿using System.ComponentModel.DataAnnotations;

namespace Final_Year_Project.Models
{
    public class AccessTypes
    {
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string AccessLevel { get; set; }
    }
}
