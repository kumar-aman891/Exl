﻿using System.Data;
using System.Data.SqlClient;

namespace Final_Year_Project.Models
{
    public class DAL
    {
        private readonly string _connectionString;
        public DAL(string connectionString)
        {
            _connectionString = connectionString;
        }
        public async Task<List<dynamic>> AccessDetails(int groupId)
        {
            var data = new List<dynamic>();

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("GetUserDetails", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GroupId", groupId);
                        conn.Open();
                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                               var item = new
                                {
                                    UserID = reader["UserID"] != DBNull.Value ? (int)reader["UserID"] : 0,
                                    Name = reader["Name"] != DBNull.Value ? (string)reader["Name"] : null,
                                    GroupName = reader["GroupName"] != DBNull.Value ? (string)reader["GroupName"] : null,
                                    AccessLevel = reader["AccessLevel"] != DBNull.Value ? (string)reader["AccessLevel"] : null
                                };
                                data.Add(item);
                            }
                        }
                        conn.Close();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return data;
        }
    }
}
