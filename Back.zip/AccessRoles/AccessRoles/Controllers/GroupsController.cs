﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceLayer.Service.Interface;

namespace Final_Year_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupsController : ControllerBase
    {
        private readonly IGroup _group;

        public GroupsController(IGroup group)
        {
            this._group = group;
        }

        [HttpGet("AccessDetails")]
        public async Task<IActionResult> AccessDetails(int groupId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var user = await _group.AccessDetails(groupId);
            if (user == null)
            {
                return Unauthorized("Invalid group id.");
            }

            return Ok(user);
        }
    }
}
