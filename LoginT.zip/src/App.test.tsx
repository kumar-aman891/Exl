import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';
import { PublicClientApplication } from '@azure/msal-browser';

const mockInstance = new PublicClientApplication({
  auth: {
    clientId: 'your_client_id_here'
    // Add other authentication configuration as needed
  }
});


test('renders learn react link', () => {
  render(<App instance={mockInstance}/>);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});
