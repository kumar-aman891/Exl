﻿using System.ComponentModel.DataAnnotations;

namespace Final_Year_Project.Models
{
    public class Groups
    {
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string GroupName { get; set; }

    }
}
