import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css"
import LocktonLogo from "../../images/locktonLogo.png"
import styles from "./Login.module.css"

interface LoginProps {
  handleOnClick: any; // Adjust type as needed
}

const  Login: React.FC<LoginProps> = ({handleOnClick}) => {
  
  
    return (
    <div>
       <div className={` ${styles.loginContainer}`}>
            <img className={styles.locktonLogoImage}  src={LocktonLogo} alt="LocktonLogo"/>
            <h2 className={styles.welcomeRxMartMessage}>Welcome to Rx Mart</h2> 
            <h5 className={styles.welcomeMessage}>Let's get Started!</h5>
          <button type="button" className={`btn btn-primary ${styles.loginButton}`} onClick={handleOnClick}>Login</button>
      </div>
      
    </div>
  )
}

export default Login;
