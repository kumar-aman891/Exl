﻿using System.ComponentModel.DataAnnotations;

namespace DomainLayer.Model
{
    public class Groups
    {
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string GroupName { get; set; }

    }
}
