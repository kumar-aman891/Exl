import { AuthenticatedTemplate, useMsal ,UnauthenticatedTemplate } from '@azure/msal-react';
import { loginRequest } from './auth-config';

export default function WrappedView() {
    const {instance} = useMsal();
    const activeAccount = instance.getActiveAccount();
  
    const handleRedirect = () => {
        instance
          .loginRedirect({
            ...loginRequest,
            prompt: 'create',
          })
          .catch((error) => console.log(error));
      };
      
  return (
    <div>
          <div className="App">
      <AuthenticatedTemplate>
        {activeAccount ? (
          <p>
            Authenticated Successfully
          </p>
        ) : null}
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <button onClick={handleRedirect}>
          Sign up
        </button>
      </UnauthenticatedTemplate>
      </div>
    </div>
  )
}
