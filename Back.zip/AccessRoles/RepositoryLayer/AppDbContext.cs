﻿using DomainLayer.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions con) : base(con) 
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<AccessTypes> AccessTypes { get; set; }
        public DbSet<Groups> Groups { get; set; }
        public DbSet<AccessMapping> AccessMapping { get; set; }
        
    }
}
