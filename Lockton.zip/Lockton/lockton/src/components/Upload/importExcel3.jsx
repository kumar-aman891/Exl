import React, { useState } from "react";
import * as XLSX from "xlsx";
import "./test.css";
import axios from "axios";

const ImportExcel3 = () => {
  // onchange states
  const [excelFile, setExcelFile] = useState(null);
  const [typeError, setTypeError] = useState(null);
  const [validationErrors, setValidationErrors] = useState([]);

  const allowedHeaders = [
    "cliendID",
    "carrierID",
    "Groups",
    "startDate",
    "terminationDate",
  ];
  // submit state
  const [excelData, setExcelData] = useState(null);

  // onchange event
  const handleFile = (e) => {
    let fileTypes = [
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "text/csv",
    ];
    let selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile && fileTypes.includes(selectedFile.type)) {
        setTypeError(null);
        let reader = new FileReader();
        reader.readAsArrayBuffer(selectedFile);
        reader.onload = (e) => {
          setExcelFile(e.target.result);
        };
      } else {
        setTypeError("Please select only Excel file types");
        setExcelFile(null);
      }
    } else {
      console.log("Please select your file");
    }
  };
  // Function to extract column headers from the Excel data
  const extractColumnHeaders = (data) => {
    if (data.length === 0) return [];
    return Object.keys(data[0]);
  };

  // Function to determine if a header should be validated
  const shouldValidateHeader = (header) => {
    return allowedHeaders.includes(header);
  };

  // submit event
  const handleFileSubmit = async (e) => {
    e.preventDefault();
    if (excelFile !== null) {
      const workbook = XLSX.read(excelFile, { type: "buffer" });
      const worksheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[worksheetName];
      const data = XLSX.utils.sheet_to_json(worksheet, { defval: null });

      console.log("Parsed Excel Data:", data);

      if (data.length === 0) {
        setValidationErrors(["No data found in the Excel file."]);
        setExcelData(null);
        return;
      }

      const validRows = [];
      const errors = [];
      const omitted = [];

      data.forEach((rowData, index) => {
        let isValid = true;
        const rowErrors = validateRow(rowData, index);
        if (rowErrors.length > 0) {
          errors.push(...rowErrors);
          isValid = false;
        }

        // Check for missing values
        Object.entries(rowData).forEach(([key, value]) => {
          if (!value) {
            omitted.push({ row: index + 1, field: key });
            isValid = false;
            // To Remove the empty cell from the row
            delete rowData[key];
          }
        });

        if (isValid) {
          validRows.push(rowData);
        }
      });

      console.log("Validation Errors:", errors);

      // Log omitted rows
      console.log("Omitted Rows:", omitted);

      if (validRows.length > 0) {
        setExcelData(validRows.slice(0, 10)); // Limiting to 10 rows for display
        setValidationErrors([]);

        // Store validRows in local storage
        localStorage.setItem("excelData", JSON.stringify(validRows));
        
      } else {
        setValidationErrors(errors);
        setExcelData(null);
      }
    }
  };

  // Function to validate a row
  const validateRow = (rowData, rowIndex) => {
    const errors = [];

    console.log(formatDate(rowData.startDate));
    // Validate clientID
    const clientIDError = validateClientID(rowData.cliendID, rowIndex);
    if (clientIDError) {
      errors.push(clientIDError);
    }

    // Validate carrierID
    const carrierIDError = validateCarrierID(rowData.carrierID, rowIndex);
    if (carrierIDError) {
      errors.push(carrierIDError);
    }

    // Validate groups
    const groupsError = validateGroups(rowData.Groups, rowIndex);
    if (groupsError) {
      errors.push(groupsError);
    }

    // Validate startDate
    const startDateError = validateStartDateFormat(
      formatDate(rowData.startDate),
      rowIndex
    );
    if (startDateError) {
      errors.push(startDateError);
    }

    // Validate terminationDate
    const terminationDateError = validateTerminationDateFormat(
      formatDate(rowData.terminationDate),
      rowIndex
    );
    if (terminationDateError) {
      errors.push(terminationDateError);
    }

    return errors;
  };

  // Function to validate clientID
  const validateClientID = (clientID, rowIndex) => {
    if (isNaN(parseInt(clientID))) {
      return `Invalid clientID at row ${rowIndex + 1}`;
    }
    return null;
  };

  // Function to validate carrierID
  const validateCarrierID = (carrierID, rowIndex) => {
    if (isNaN(parseInt(carrierID))) {
      return `Invalid carrierID at row ${rowIndex + 1}`;
    }
    return null;
  };

  // Function to validate groups
  const validateGroups = (groups, rowIndex) => {
    if (groups === "") {
      return null; // No error for missing value
    }
    if (typeof groups !== "string") {
      return `Invalid Groups at row ${rowIndex + 1}`;
    }
    return null;
  };

  // Function to validate date format (MM-DD-YYYY)
  const validateStartDateFormat = (dateString, rowIndex) => {
    const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
    if (!dateRegex.test(dateString)) {
      return `Invalid Start date format at row ${rowIndex + 1}`;
    }
    return null;
  };
  const validateTerminationDateFormat = (dateString, rowIndex) => {
    const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
    if (!dateRegex.test(dateString)) {
      return `Invalid Termination date format at row ${rowIndex + 1}`;
    }
    return null;
  };
  // Function to format date from number to MM-DD-YYYY string
  const formatDate = (dateNumber) => {
    const date = new Date((dateNumber - (25567 + 2)) * 86400 * 1000);
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  return (
    <div className="wrapper">
      <h3>Upload & View Excel Sheets</h3>

      {/* form */}
      <form className="form-group custom-form" onSubmit={handleFileSubmit}>
        <input
          type="file"
          className="form-control"
          required
          onChange={handleFile}
        />
        <button type="submit" className="btn btn-success btn-md">
          UPLOAD
        </button>
        {typeError && (
          <div className="alert alert-danger" role="alert">
            {typeError}
          </div>
        )}
      </form>

      {/* Show validation errors */}
      {validationErrors.length > 0 && (
        <div className="alert alert-danger" role="alert">
          <h4>Validation Errors:</h4>
          <ul>
            {validationErrors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* view data */}
      <div className="viewer">
        {excelData ? (
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  {/* To render coloumns dynamically */}
                  {extractColumnHeaders(excelData).map((header, index) => (
                    <th key={index}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {excelData.map((rowData, rowIndex) => (
                  <tr key={rowIndex}>
                    {extractColumnHeaders(excelData).map((header, colIndex) => (
                      <td key={colIndex}>
                        {/* Apply validations only to allowed headers */}
                        {shouldValidateHeader(header)
                          ? (() => {
                              switch (header) {
                                case "cliendID":
                                  return (
                                    validateClientID(
                                      rowData[header],
                                      rowIndex
                                    ) || rowData[header]
                                  );
                                case "carrierID":
                                  return (
                                    validateCarrierID(
                                      rowData[header],
                                      rowIndex
                                    ) || rowData[header]
                                  );
                                case "Groups":
                                  return (
                                    validateGroups(rowData[header], rowIndex) ||
                                    rowData[header]
                                  );
                                case "startDate":
                                  return (
                                    validateStartDateFormat(
                                      formatDate(rowData[header]),
                                      rowIndex
                                    ) || formatDate(rowData[header])
                                  );
                                case "terminationDate":
                                  return (
                                    validateTerminationDateFormat(
                                      formatDate(rowData[header]),
                                      rowIndex
                                    ) || formatDate(rowData[header])
                                  );
                                default:
                                  return rowData[header]; // For other headers, display without validation
                              }
                            })()
                          : // Display cell value without validation for other headers
                            rowData[header]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div>No File is uploaded yet!</div>
        )}
      </div>
    </div>
  );
};

export default ImportExcel3;
