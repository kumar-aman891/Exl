﻿namespace DomainLayer.Model
{
    public class AccessMapping
    {
        public int ID { get; set; }
        public int GroupID { get; set; }
        public int UserID { get; set; }
    }
}
