import './App.css';
import Login from './Login';
import { MsalProvider} from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';



  const App = ({instance}: {instance: PublicClientApplication}) => {
    return (
      <MsalProvider instance={instance}>
        <Login/>
      </MsalProvider>
    );
  };
  export default App;
        