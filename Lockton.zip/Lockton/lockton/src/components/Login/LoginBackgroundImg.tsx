import React from 'react';
import styles from './LoginBackgroundImg.module.css';
import LoginBackgroundImage from "../../images/LoginBackgroundImage.jpg"

const LoginBackgroundImg: React.FC = () =>{
    return <>
    <img className={styles.backgroundImage} src={LoginBackgroundImage} alt="MyI"
      />
    </>
}
export default LoginBackgroundImg;