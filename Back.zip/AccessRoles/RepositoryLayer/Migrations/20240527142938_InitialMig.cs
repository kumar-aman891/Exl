﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RepositoryLayer.Migrations
{
    /// <inheritdoc />
    public partial class InitialMig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AccessMappings",
                table: "AccessMappings");

            migrationBuilder.RenameTable(
                name: "AccessMappings",
                newName: "AccessMapping");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AccessMapping",
                table: "AccessMapping",
                column: "ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AccessMapping",
                table: "AccessMapping");

            migrationBuilder.RenameTable(
                name: "AccessMapping",
                newName: "AccessMappings");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AccessMappings",
                table: "AccessMappings",
                column: "ID");
        }
    }
}
