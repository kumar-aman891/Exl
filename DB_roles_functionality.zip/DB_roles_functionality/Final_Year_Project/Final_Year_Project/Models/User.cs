﻿using System.ComponentModel.DataAnnotations;

namespace Final_Year_Project.Models
{
    public class User
    {
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

    }
}
