import './App.css';
import Login from './Login';
import WrappedView from './WrappedView';
import { MsalProvider} from '@azure/msal-react';



  const App = ({instance}) => {
    return (
      <MsalProvider instance={instance}>
        {/* <WrappedView /> */}
        <Login/>
      </MsalProvider>
    );
  };
  export default App;
        